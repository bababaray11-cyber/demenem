package com.mclogger;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

public class LogEntry {

    public enum LogType {
        JOIN, LEAVE, COMMAND, ERROR
    }

    private final LogType type;
    private final String player;
    private final String message;
    private final long timestamp;
    private final String ip;

    public LogEntry(LogType type, String player, String message, String ip) {
        this.type    = type;
        this.player  = player;
        this.message = message;
        this.ip      = ip;
        this.timestamp = System.currentTimeMillis();
    }

    /** Dosyadan yüklenirken kullanılır */
    public LogEntry(LogType type, String player, String message, String ip, long timestamp) {
        this.type      = type;
        this.player    = player;
        this.message   = message;
        this.ip        = ip;
        this.timestamp = timestamp;
    }

    public LogType getType()    { return type; }
    public String  getPlayer()  { return player; }
    public String  getMessage() { return message; }
    public long    getTimestamp(){ return timestamp; }
    public String  getIp()      { return ip; }

    public String getFormattedTime() {
        return DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm:ss")
                .withZone(ZoneId.systemDefault())
                .format(Instant.ofEpochMilli(timestamp));
    }

    /** JSON nesnesine çevirir (Gson olmadan sade string birleştirme) */
    public String toJson() {
        return String.format(
            "{\"type\":\"%s\",\"player\":\"%s\",\"message\":\"%s\",\"timestamp\":%d,\"time\":\"%s\",\"ip\":\"%s\"}",
            type.name(),
            escapeJson(player),
            escapeJson(message),
            timestamp,
            getFormattedTime(),
            escapeJson(ip == null ? "" : ip)
        );
    }

    private static String escapeJson(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }
}
