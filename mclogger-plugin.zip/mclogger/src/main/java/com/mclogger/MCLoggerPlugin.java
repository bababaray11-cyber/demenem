package com.mclogger;

import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.LogRecord;

public class MCLoggerPlugin extends JavaPlugin {

    private static MCLoggerPlugin instance;
    private final CopyOnWriteArrayList<LogEntry> logs = new CopyOnWriteArrayList<>();
    private WebServer webServer;
    private Handler errorHandler;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        // Mevcut logları yükle
        loadLogs();

        // Hata loglarını yakala
        if (getConfig().getBoolean("log-errors", true)) {
            setupErrorHandler();
        }

        // Web sunucusunu başlat
        int port = getConfig().getInt("web-port", 8080);
        webServer = new WebServer(this, port);
        webServer.start();

        // Olayları kaydet
        getServer().getPluginManager().registerEvents(new EventListener(this), this);

        String password = getConfig().getString("web-password", "");
        getLogger().info("════════════════════════════════");
        getLogger().info("  MCLogger aktif!");
        getLogger().info("  Panel: http://<sunucu-ip>:" + port);
        if (!password.isEmpty()) {
            getLogger().info("  Şifre koruması: AÇIK");
        }
        getLogger().info("════════════════════════════════");
    }

    @Override
    public void onDisable() {
        if (webServer != null) webServer.stop();
        if (errorHandler != null) {
            java.util.logging.Logger.getLogger("").removeHandler(errorHandler);
        }
        saveLogs();
        getLogger().info("MCLogger durduruldu. Loglar kaydedildi.");
    }

    /* ── Komutlar ── */
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!cmd.getName().equalsIgnoreCase("mclogs")) return false;
        if (!sender.hasPermission("mclogger.admin")) {
            sender.sendMessage("§cBu komutu kullanma yetkiniz yok.");
            return true;
        }
        if (args.length == 0) {
            int port = getConfig().getInt("web-port", 8080);
            sender.sendMessage("§a[MCLogger] §fPanel: §bhttp://<sunucu-ip>:" + port);
            sender.sendMessage("§a[MCLogger] §fToplam log: §e" + logs.size());
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "reload":
                reloadConfig();
                sender.sendMessage("§a[MCLogger] §fAyarlar yeniden yüklendi.");
                break;
            case "clear":
                logs.clear();
                saveLogs();
                sender.sendMessage("§a[MCLogger] §fTüm loglar temizlendi.");
                break;
            default:
                sender.sendMessage("§cKullanım: /mclogs [reload|clear]");
        }
        return true;
    }

    /* ── Log ekleme ── */
    public void addLog(LogEntry entry) {
        logs.add(0, entry); // en yeni en üstte
        int maxLogs = getConfig().getInt("max-logs", 500);
        while (logs.size() > maxLogs) {
            logs.remove(logs.size() - 1);
        }
        // Dosyayı arka planda güncelle (her 10 logda bir)
        if (logs.size() % 10 == 0) {
            getServer().getScheduler().runTaskAsynchronously(this, this::saveLogs);
        }
    }

    public List<LogEntry> getLogs() {
        return logs;
    }

    /* ── Hata handler ── */
    private void setupErrorHandler() {
        errorHandler = new Handler() {
            @Override
            public void publish(LogRecord record) {
                if (record.getLevel().intValue() < Level.WARNING.intValue()) return;
                String message = record.getMessage();
                if (message == null) return;
                Throwable thrown = record.getThrown();
                if (thrown != null) message += " — " + thrown.getClass().getSimpleName() + ": " + thrown.getMessage();
                addLog(new LogEntry(LogEntry.LogType.ERROR, "SERVER", message, ""));
            }
            @Override public void flush() {}
            @Override public void close() {}
        };
        java.util.logging.Logger.getLogger("").addHandler(errorHandler);
    }

    /* ── Kalıcı saklama ── */
    private void saveLogs() {
        File dataFolder = getDataFolder();
        if (!dataFolder.exists()) dataFolder.mkdirs();
        File f = new File(dataFolder, "logs.json");
        try (Writer w = new OutputStreamWriter(new FileOutputStream(f), StandardCharsets.UTF_8)) {
            w.write("[");
            for (int i = 0; i < logs.size(); i++) {
                if (i > 0) w.write(",");
                w.write(logs.get(i).toJson());
            }
            w.write("]");
        } catch (IOException e) {
            getLogger().warning("Loglar kaydedilemedi: " + e.getMessage());
        }
    }

    private void loadLogs() {
        File f = new File(getDataFolder(), "logs.json");
        if (!f.exists()) return;
        try (Reader r = new InputStreamReader(new FileInputStream(f), StandardCharsets.UTF_8)) {
            StringBuilder sb = new StringBuilder();
            int ch;
            while ((ch = r.read()) != -1) sb.append((char) ch);
            // Basit JSON ayrıştırma (her satır bir log nesnesi)
            String json = sb.toString().trim();
            if (json.isEmpty() || json.equals("[]")) return;
            // LogEntry JSON'larını elle ayrıştır
            String[] entries = json.substring(1, json.length()-1).split("(?<=\\}),(?=\\{)");
            for (String entry : entries) {
                try {
                    LogEntry.LogType type = LogEntry.LogType.valueOf(extract(entry, "type"));
                    String player  = extract(entry, "player");
                    String message = extract(entry, "message");
                    String ip      = extract(entry, "ip");
                    long ts        = Long.parseLong(extract(entry, "timestamp"));
                    logs.add(new LogEntry(type, player, message, ip, ts));
                } catch (Exception ignored) {}
            }
            getLogger().info(logs.size() + " log yüklendi.");
        } catch (IOException e) {
            getLogger().warning("Loglar yüklenemedi: " + e.getMessage());
        }
    }

    private static String extract(String json, String key) {
        String token = "\"" + key + "\":";
        int idx = json.indexOf(token);
        if (idx < 0) return "";
        int start = idx + token.length();
        if (json.charAt(start) == '"') {
            start++;
            int end = json.indexOf('"', start);
            return json.substring(start, end).replace("\\\"","\"").replace("\\n","\n");
        } else {
            int end = json.indexOf(',', start);
            if (end < 0) end = json.indexOf('}', start);
            return json.substring(start, end).trim();
        }
    }

    public static MCLoggerPlugin getInstance() { return instance; }
}
