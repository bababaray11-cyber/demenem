package com.mclogger;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.io.*;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

public class WebServer {

    private final MCLoggerPlugin plugin;
    private final int port;
    private HttpServer server;

    /* ───── HTML şablonu ───── */
    private static final String HTML = "<!DOCTYPE html>\n" +
"<html lang='tr'>\n" +
"<head>\n" +
"<meta charset='UTF-8'>\n" +
"<meta name='viewport' content='width=device-width,initial-scale=1'>\n" +
"<title>MCLogger – Sunucu Paneli</title>\n" +
"<style>\n" +
"  :root{--bg:#0f1117;--surface:#1a1d2e;--border:#2a2d3e;--accent:#5865f2;\n" +
"        --join:#57f287;--leave:#ed4245;--cmd:#fee75c;--err:#eb459e;\n" +
"        --text:#e3e5e8;--sub:#8b8fa8;}\n" +
"  *{box-sizing:border-box;margin:0;padding:0;}\n" +
"  body{background:var(--bg);color:var(--text);font-family:'Segoe UI',sans-serif;min-height:100vh;}\n" +
"  header{background:var(--surface);border-bottom:1px solid var(--border);\n" +
"         padding:16px 28px;display:flex;align-items:center;gap:14px;}\n" +
"  header img{width:36px;height:36px;}\n" +
"  header h1{font-size:1.25rem;font-weight:700;letter-spacing:.5px;}\n" +
"  header span{margin-left:auto;font-size:.8rem;color:var(--sub);}\n" +
"  .dot{width:8px;height:8px;border-radius:50%;background:var(--join);display:inline-block;margin-right:6px;animation:pulse 2s infinite;}\n" +
"  @keyframes pulse{0%,100%{opacity:1;}50%{opacity:.4;}}\n" +
"  .container{max-width:1200px;margin:0 auto;padding:24px 20px;}\n" +
"  .stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:14px;margin-bottom:24px;}\n" +
"  .stat{background:var(--surface);border:1px solid var(--border);border-radius:12px;padding:16px 20px;}\n" +
"  .stat .val{font-size:2rem;font-weight:800;}\n" +
"  .stat .lbl{font-size:.75rem;color:var(--sub);margin-top:4px;text-transform:uppercase;letter-spacing:.8px;}\n" +
"  .join-val{color:var(--join);} .leave-val{color:var(--leave);} .cmd-val{color:var(--cmd);} .err-val{color:var(--err);}\n" +
"  .toolbar{display:flex;gap:10px;margin-bottom:16px;flex-wrap:wrap;}\n" +
"  .toolbar input{flex:1;min-width:200px;background:var(--surface);border:1px solid var(--border);\n" +
"                 border-radius:8px;padding:9px 14px;color:var(--text);font-size:.9rem;outline:none;}\n" +
"  .toolbar input:focus{border-color:var(--accent);}\n" +
"  .filters{display:flex;gap:8px;flex-wrap:wrap;}\n" +
"  .filter-btn{padding:7px 16px;border-radius:20px;border:1px solid var(--border);\n" +
"              background:transparent;color:var(--sub);cursor:pointer;font-size:.82rem;transition:.15s;}\n" +
"  .filter-btn:hover,.filter-btn.active{color:#fff;border-color:transparent;}\n" +
"  .filter-btn.active.all  {background:var(--accent);}\n" +
"  .filter-btn.active.join {background:var(--join);color:#000;}\n" +
"  .filter-btn.active.leave{background:var(--leave);}\n" +
"  .filter-btn.active.cmd  {background:var(--cmd);color:#000;}\n" +
"  .filter-btn.active.err  {background:var(--err);}\n" +
"  table{width:100%;border-collapse:collapse;background:var(--surface);\n" +
"        border-radius:12px;overflow:hidden;border:1px solid var(--border);}\n" +
"  th{padding:11px 16px;text-align:left;font-size:.75rem;text-transform:uppercase;\n" +
"     letter-spacing:.8px;color:var(--sub);border-bottom:1px solid var(--border);}\n" +
"  td{padding:10px 16px;font-size:.88rem;border-bottom:1px solid var(--border);vertical-align:middle;}\n" +
"  tr:last-child td{border-bottom:none;}\n" +
"  tr:hover td{background:rgba(255,255,255,.025);}\n" +
"  .badge{display:inline-block;padding:2px 10px;border-radius:20px;font-size:.72rem;\n" +
"         font-weight:700;letter-spacing:.5px;}\n" +
"  .JOIN  {background:rgba(87,242,135,.15);color:var(--join);}\n" +
"  .LEAVE {background:rgba(237,66,69,.15);color:var(--leave);}\n" +
"  .COMMAND{background:rgba(254,231,92,.15);color:var(--cmd);}\n" +
"  .ERROR {background:rgba(235,69,158,.15);color:var(--err);}\n" +
"  .time{color:var(--sub);font-size:.78rem;white-space:nowrap;}\n" +
"  .empty{text-align:center;padding:60px;color:var(--sub);}\n" +
"  .refresh-btn{padding:8px 18px;background:var(--accent);border:none;border-radius:8px;\n" +
"               color:#fff;cursor:pointer;font-size:.85rem;transition:.15s;}\n" +
"  .refresh-btn:hover{opacity:.85;}\n" +
"  footer{text-align:center;padding:20px;color:var(--sub);font-size:.75rem;}\n" +
"</style>\n" +
"</head>\n" +
"<body>\n" +
"<header>\n" +
"  <div style='background:#5865f2;border-radius:8px;width:36px;height:36px;display:flex;align-items:center;justify-content:center;font-size:1.2rem;'>⛏</div>\n" +
"  <h1>MCLogger</h1>\n" +
"  <span><span class='dot'></span>Canlı &nbsp;|&nbsp; <span id='lastUpdate'>–</span></span>\n" +
"</header>\n" +
"\n" +
"<div class='container'>\n" +
"  <div class='stats'>\n" +
"    <div class='stat'><div class='val join-val'  id='cJoin'>–</div><div class='lbl'>Katılım</div></div>\n" +
"    <div class='stat'><div class='val leave-val' id='cLeave'>–</div><div class='lbl'>Ayrılış</div></div>\n" +
"    <div class='stat'><div class='val cmd-val'   id='cCmd'>–</div><div class='lbl'>Komut</div></div>\n" +
"    <div class='stat'><div class='val err-val'   id='cErr'>–</div><div class='lbl'>Hata</div></div>\n" +
"  </div>\n" +
"\n" +
"  <div class='toolbar'>\n" +
"    <input id='search' type='text' placeholder='🔍  Oyuncu adı veya mesaj ara…'>\n" +
"    <button class='refresh-btn' onclick='fetchLogs()'>↻ Yenile</button>\n" +
"  </div>\n" +
"  <div class='filters'>\n" +
"    <button class='filter-btn active all'  onclick=\"setFilter('ALL')\">Tümü</button>\n" +
"    <button class='filter-btn join'  onclick=\"setFilter('JOIN')\">Katılım</button>\n" +
"    <button class='filter-btn leave' onclick=\"setFilter('LEAVE')\">Ayrılış</button>\n" +
"    <button class='filter-btn cmd'   onclick=\"setFilter('COMMAND')\">Komut</button>\n" +
"    <button class='filter-btn err'   onclick=\"setFilter('ERROR')\">Hata</button>\n" +
"  </div>\n" +
"\n" +
"  <br>\n" +
"  <table>\n" +
"    <thead><tr>\n" +
"      <th>Tür</th><th>Oyuncu</th><th>Mesaj</th><th>IP</th><th>Zaman</th>\n" +
"    </tr></thead>\n" +
"    <tbody id='logBody'><tr><td colspan='5' class='empty'>Yükleniyor…</td></tr></tbody>\n" +
"  </table>\n" +
"</div>\n" +
"<footer>MCLogger v1.0.0 &mdash; Sunucu Log Paneli</footer>\n" +
"\n" +
"<script>\n" +
"let allLogs=[], currentFilter='ALL';\n" +
"\n" +
"async function fetchLogs(){\n" +
"  try{\n" +
"    const r=await fetch('/api/logs');\n" +
"    allLogs=await r.json();\n" +
"    document.getElementById('lastUpdate').textContent=new Date().toLocaleTimeString('tr-TR');\n" +
"    updateStats(); renderTable();\n" +
"  }catch(e){console.error(e);}\n" +
"}\n" +
"\n" +
"function updateStats(){\n" +
"  document.getElementById('cJoin').textContent =allLogs.filter(l=>l.type==='JOIN').length;\n" +
"  document.getElementById('cLeave').textContent=allLogs.filter(l=>l.type==='LEAVE').length;\n" +
"  document.getElementById('cCmd').textContent  =allLogs.filter(l=>l.type==='COMMAND').length;\n" +
"  document.getElementById('cErr').textContent  =allLogs.filter(l=>l.type==='ERROR').length;\n" +
"}\n" +
"\n" +
"function renderTable(){\n" +
"  const q=document.getElementById('search').value.toLowerCase();\n" +
"  const filtered=allLogs.filter(l=>{\n" +
"    const typeOk=currentFilter==='ALL'||l.type===currentFilter;\n" +
"    const searchOk=!q||(l.player&&l.player.toLowerCase().includes(q))||(l.message&&l.message.toLowerCase().includes(q));\n" +
"    return typeOk&&searchOk;\n" +
"  });\n" +
"  const tbody=document.getElementById('logBody');\n" +
"  if(!filtered.length){\n" +
"    tbody.innerHTML='<tr><td colspan=\"5\" class=\"empty\">Gösterilecek log yok</td></tr>'; return;\n" +
"  }\n" +
"  tbody.innerHTML=filtered.map(l=>`\n" +
"    <tr>\n" +
"      <td><span class='badge ${l.type}'>${label(l.type)}</span></td>\n" +
"      <td>${esc(l.player)}</td>\n" +
"      <td>${esc(l.message)}</td>\n" +
"      <td style='color:var(--sub);font-size:.78rem'>${esc(l.ip)}</td>\n" +
"      <td class='time'>${esc(l.time)}</td>\n" +
"    </tr>`).join('');\n" +
"}\n" +
"\n" +
"function label(t){return{JOIN:'KATIILDI',LEAVE:'AYRILDI',COMMAND:'KOMUT',ERROR:'HATA'}[t]||t;}\n" +
"function esc(s){if(!s)return'';return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');}\n" +
"\n" +
"function setFilter(f){\n" +
"  currentFilter=f;\n" +
"  document.querySelectorAll('.filter-btn').forEach(b=>b.classList.remove('active'));\n" +
"  const map={ALL:'all',JOIN:'join',LEAVE:'leave',COMMAND:'cmd',ERROR:'err'};\n" +
"  document.querySelector('.filter-btn.'+map[f]).classList.add('active');\n" +
"  renderTable();\n" +
"}\n" +
"\n" +
"document.getElementById('search').addEventListener('input',renderTable);\n" +
"fetchLogs();\n" +
"setInterval(fetchLogs,10000); // 10 saniyede bir otomatik yenile\n" +
"</script>\n" +
"</body></html>\n";

    public WebServer(MCLoggerPlugin plugin, int port) {
        this.plugin = plugin;
        this.port   = port;
    }

    public void start() {
        try {
            server = HttpServer.create(new InetSocketAddress(port), 0);
            server.createContext("/",        this::handleRoot);
            server.createContext("/api/logs", this::handleLogs);
            server.setExecutor(Executors.newFixedThreadPool(4));
            server.start();
            plugin.getLogger().info("Web paneli açık → http://localhost:" + port);
        } catch (IOException e) {
            plugin.getLogger().severe("Web sunucusu başlatılamadı: " + e.getMessage());
        }
    }

    public void stop() {
        if (server != null) server.stop(1);
    }

    /* ── / → HTML ── */
    private void handleRoot(HttpExchange ex) throws IOException {
        if (!ex.getRequestMethod().equalsIgnoreCase("GET")) { ex.sendResponseHeaders(405,-1); return; }

        // Şifre kontrolü
        String password = plugin.getConfig().getString("web-password","");
        if (!password.isEmpty()) {
            String auth = ex.getRequestHeaders().getFirst("Authorization");
            String expected = "Basic " + java.util.Base64.getEncoder().encodeToString(("admin:" + password).getBytes());
            if (auth == null || !auth.equals(expected)) {
                ex.getResponseHeaders().set("WWW-Authenticate","Basic realm=\"MCLogger\"");
                ex.sendResponseHeaders(401,-1);
                return;
            }
        }

        byte[] bytes = HTML.getBytes(StandardCharsets.UTF_8);
        ex.getResponseHeaders().set("Content-Type","text/html; charset=utf-8");
        ex.sendResponseHeaders(200, bytes.length);
        try (OutputStream os = ex.getResponseBody()) { os.write(bytes); }
    }

    /* ── /api/logs → JSON ── */
    private void handleLogs(HttpExchange ex) throws IOException {
        if (!ex.getRequestMethod().equalsIgnoreCase("GET")) { ex.sendResponseHeaders(405,-1); return; }

        List<LogEntry> logs = plugin.getLogs();
        String json = "[" + logs.stream().map(LogEntry::toJson).collect(Collectors.joining(",")) + "]";
        byte[] bytes = json.getBytes(StandardCharsets.UTF_8);

        ex.getResponseHeaders().set("Content-Type","application/json; charset=utf-8");
        ex.getResponseHeaders().set("Access-Control-Allow-Origin","*");
        ex.sendResponseHeaders(200, bytes.length);
        try (OutputStream os = ex.getResponseBody()) { os.write(bytes); }
    }
}
