package com.mclogger;

import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.server.ServerCommandEvent;

import java.util.List;

public class EventListener implements Listener {

    private final MCLoggerPlugin plugin;

    public EventListener(MCLoggerPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent e) {
        if (!plugin.getConfig().getBoolean("log-join-leave", true)) return;

        String ip = "";
        if (e.getPlayer().getAddress() != null) {
            ip = e.getPlayer().getAddress().getAddress().getHostAddress();
        }

        plugin.addLog(new LogEntry(
            LogEntry.LogType.JOIN,
            e.getPlayer().getName(),
            e.getPlayer().getName() + " sunucuya katıldı",
            ip
        ));
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent e) {
        if (!plugin.getConfig().getBoolean("log-join-leave", true)) return;

        plugin.addLog(new LogEntry(
            LogEntry.LogType.LEAVE,
            e.getPlayer().getName(),
            e.getPlayer().getName() + " sunucudan ayrıldı",
            ""
        ));
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        if (!plugin.getConfig().getBoolean("log-commands", true)) return;

        String cmd = e.getMessage();

        // Gizli komutları filtrele
        List<String> hidden = plugin.getConfig().getStringList("hidden-commands");
        for (String h : hidden) {
            if (cmd.toLowerCase().startsWith(h.toLowerCase())) return;
        }

        plugin.addLog(new LogEntry(
            LogEntry.LogType.COMMAND,
            e.getPlayer().getName(),
            e.getPlayer().getName() + " komut kullandı: " + cmd,
            ""
        ));
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onServerCommand(ServerCommandEvent e) {
        if (!plugin.getConfig().getBoolean("log-commands", true)) return;

        String cmd = e.getCommand();
        if (cmd == null || cmd.isBlank()) return;

        plugin.addLog(new LogEntry(
            LogEntry.LogType.COMMAND,
            "CONSOLE",
            "Konsol komutu: /" + cmd,
            "127.0.0.1"
        ));
    }
}
