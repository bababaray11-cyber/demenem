package com.mcadmin;

import com.mcadmin.discord.DiscordBot;
import com.mcadmin.discord.DiscordLogger;
import com.mcadmin.listeners.PlayerEvents;
import org.bukkit.plugin.java.JavaPlugin;

public class AdminBridge extends JavaPlugin {

    private static AdminBridge instance;
    private DiscordBot discordBot;
    private DiscordLogger discordLogger;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();
        reloadConfig();

        discordLogger = new DiscordLogger(this);

        String token = getConfig().getString("discord.bot-token", "");
        String commandChannel = getConfig().getString("discord.command-channel-id", "");

        if (!token.isEmpty() && !token.equals("TOKEN_BURAYA")) {
            discordBot = new DiscordBot(this, token, commandChannel);
        } else {
            getLogger().warning("Discord bot token ayarlanmamış! config.yml dosyasını düzenleyin.");
        }

        getServer().getPluginManager().registerEvents(new PlayerEvents(this), this);

        getLogger().info("AdminBridge aktif! ✅");
    }

    @Override
    public void onDisable() {
        if (discordBot != null) {
            discordBot.shutdown();
        }
        getLogger().info("AdminBridge kapatıldı.");
    }

    public static AdminBridge getInstance() { return instance; }
    public DiscordBot getDiscordBot() { return discordBot; }
    public DiscordLogger getDiscordLogger() { return discordLogger; }
}
