package com.mcadmin.listeners;

import com.mcadmin.AdminBridge;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class PlayerEvents implements Listener {

    private final AdminBridge plugin;

    public PlayerEvents(AdminBridge plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();

        // Action bar mesajı
        String rawMsg = plugin.getConfig().getString("messages.join-actionbar", "✦ Sunucuya Hoş Geldin, {player}! ✦");
        String msg = rawMsg.replace("{player}", player.getName());

        // Biraz gecikme ile göster (yükleme bitmesini bekle)
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (player.isOnline()) {
                player.sendActionBar(Component.text(msg, NamedTextColor.GOLD));
            }
        }, 10L); // 0.5 saniye bekle

        // Discord log
        plugin.getDiscordLogger().logJoin(player);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent event) {
        plugin.getDiscordLogger().logQuit(event.getPlayer());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        Component deathComponent = event.deathMessage();
        String deathMsg = deathComponent != null
                ? PlainTextComponentSerializer.plainText().serialize(deathComponent)
                : player.getName() + " öldü";
        plugin.getDiscordLogger().logDeath(player, deathMsg);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent event) {
        plugin.getDiscordLogger().logCommand(event.getPlayer(), event.getMessage());
    }
}
