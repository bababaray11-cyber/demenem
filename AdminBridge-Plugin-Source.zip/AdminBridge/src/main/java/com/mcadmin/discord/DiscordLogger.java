package com.mcadmin.discord;

import com.mcadmin.AdminBridge;
import org.bukkit.entity.Player;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class DiscordLogger {

    private final AdminBridge plugin;

    public DiscordLogger(AdminBridge plugin) {
        this.plugin = plugin;
    }

    private void sendWebhook(String webhookUrl, String content) {
        if (webhookUrl == null || webhookUrl.isEmpty() || webhookUrl.equals("WEBHOOK_URL_BURAYA")) return;

        plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                URL url = new URL(webhookUrl);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                conn.setRequestProperty("User-Agent", "AdminBridge/1.0");
                conn.setDoOutput(true);
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(5000);

                // JSON escape
                String escaped = content
                        .replace("\\", "\\\\")
                        .replace("\"", "\\\"")
                        .replace("\n", "\\n")
                        .replace("\r", "");

                String json = "{\"content\":\"" + escaped + "\",\"allowed_mentions\":{\"parse\":[]}}";

                try (OutputStream os = conn.getOutputStream()) {
                    os.write(json.getBytes(StandardCharsets.UTF_8));
                }

                int responseCode = conn.getResponseCode();
                if (responseCode != 204 && responseCode != 200) {
                    plugin.getLogger().warning("Discord webhook hata kodu: " + responseCode);
                }
                conn.disconnect();
            } catch (Exception e) {
                plugin.getLogger().warning("Discord webhook hatası: " + e.getMessage());
            }
        });
    }

    public void logJoin(Player player) {
        String webhook = plugin.getConfig().getString("webhooks.join-leave", "");
        sendWebhook(webhook, "🟢 **" + player.getName() + "** sunucuya bağlandı.");
    }

    public void logQuit(Player player) {
        String webhook = plugin.getConfig().getString("webhooks.join-leave", "");
        sendWebhook(webhook, "🔴 **" + player.getName() + "** sunucudan ayrıldı.");
    }

    public void logDeath(Player player, String deathMessage) {
        String webhook = plugin.getConfig().getString("webhooks.deaths", "");
        sendWebhook(webhook, "💀 " + deathMessage);
    }

    public void logCommand(Player player, String command) {
        String webhook = plugin.getConfig().getString("webhooks.commands", "");
        sendWebhook(webhook, "⌨️ **" + player.getName() + "** → `" + command + "`");
    }
}
