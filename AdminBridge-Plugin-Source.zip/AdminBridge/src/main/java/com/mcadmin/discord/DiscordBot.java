package com.mcadmin.discord;

import com.mcadmin.AdminBridge;
import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.JDABuilder;
import net.dv8tion.jda.api.entities.channel.concrete.TextChannel;
import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import net.dv8tion.jda.api.requests.GatewayIntent;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public class DiscordBot extends ListenerAdapter {

    private final AdminBridge plugin;
    private final String commandChannelId;
    private JDA jda;

    public DiscordBot(AdminBridge plugin, String token, String commandChannelId) {
        this.plugin = plugin;
        this.commandChannelId = commandChannelId;

        try {
            jda = JDABuilder.createDefault(token)
                    .enableIntents(
                            GatewayIntent.MESSAGE_CONTENT,
                            GatewayIntent.GUILD_MESSAGES
                    )
                    .addEventListeners(this)
                    .build();
            plugin.getLogger().info("Discord bot bağlantısı kuruldu! ✅");
        } catch (Exception e) {
            plugin.getLogger().severe("Discord bot başlatılamadı: " + e.getMessage());
        }
    }

    private void reply(MessageReceivedEvent event, String message) {
        event.getChannel().sendMessage(message).queue(
                success -> {},
                error -> plugin.getLogger().warning("Discord mesaj gönderilemedi: " + error.getMessage())
        );
    }

    @Override
    public void onMessageReceived(MessageReceivedEvent event) {
        if (event.getAuthor().isBot()) return;
        if (!event.getChannel().getId().equals(commandChannelId)) return;

        String content = event.getMessage().getContentRaw().trim();
        if (!content.startsWith("/")) return;

        String[] parts = content.substring(1).split(" ", 3);
        String command = parts[0].toLowerCase();
        String arg1 = parts.length > 1 ? parts[1] : "";
        String arg2 = parts.length > 2 ? parts[2] : "";

        switch (command) {
            case "kick"       -> cmdKick(event, arg1, arg2.isEmpty() ? "Discord'dan atıldınız." : arg2);
            case "ban"        -> cmdBan(event, arg1, arg2.isEmpty() ? "Yasaklandınız." : arg2);
            case "unban"      -> cmdUnban(event, arg1);
            case "broadcast"  -> cmdBroadcast(event, content.substring(content.indexOf(' ') + 1));
            case "list"       -> cmdList(event);
            case "lightning"  -> cmdLightning(event, arg1);
            case "fakequit"   -> cmdFakeQuit(event, arg1);
            case "fakejoin"   -> cmdFakeJoin(event, arg1);
            case "yardim", "help", "komutlar" -> cmdHelp(event);
            default -> reply(event, "❓ Bilinmeyen komut. `/yardim` yaz.");
        }
    }

    // ─── Komutlar ───────────────────────────────────────────────────────────────

    private void cmdKick(MessageReceivedEvent event, String playerName, String reason) {
        if (playerName.isEmpty()) { reply(event, "❌ Kullanım: `/kick <oyuncu> [sebep]`"); return; }
        Bukkit.getScheduler().runTask(plugin, () -> {
            Player target = Bukkit.getPlayerExact(playerName);
            if (target == null) { reply(event, "❌ **" + playerName + "** şu an çevrimiçi değil."); return; }
            target.kickPlayer(reason);
            reply(event, "✅ **" + target.getName() + "** sunucudan atıldı. Sebep: " + reason);
        });
    }

    private void cmdBan(MessageReceivedEvent event, String playerName, String reason) {
        if (playerName.isEmpty()) { reply(event, "❌ Kullanım: `/ban <oyuncu> [sebep]`"); return; }
        Bukkit.getScheduler().runTask(plugin, () -> {
            Bukkit.getBanList(org.bukkit.BanList.Type.NAME).addBan(playerName, reason, null, "Discord Admin");
            Player target = Bukkit.getPlayerExact(playerName);
            if (target != null) target.kickPlayer("Yasaklandınız: " + reason);
            reply(event, "🔨 **" + playerName + "** yasaklandı. Sebep: " + reason);
        });
    }

    private void cmdUnban(MessageReceivedEvent event, String playerName) {
        if (playerName.isEmpty()) { reply(event, "❌ Kullanım: `/unban <oyuncu>`"); return; }
        Bukkit.getScheduler().runTask(plugin, () -> {
            Bukkit.getBanList(org.bukkit.BanList.Type.NAME).pardon(playerName);
            reply(event, "✅ **" + playerName + "** yasağı kaldırıldı.");
        });
    }

    private void cmdBroadcast(MessageReceivedEvent event, String message) {
        if (message.isBlank()) { reply(event, "❌ Kullanım: `/broadcast <mesaj>`"); return; }
        Bukkit.getScheduler().runTask(plugin, () -> {
            Bukkit.broadcastMessage("§6[Duyuru] §f" + message);
            reply(event, "📢 Duyuru gönderildi: **" + message + "**");
        });
    }

    private void cmdList(MessageReceivedEvent event) {
        Bukkit.getScheduler().runTask(plugin, () -> {
            var players = Bukkit.getOnlinePlayers();
            if (players.isEmpty()) {
                reply(event, "😴 Şu an hiç oyuncu çevrimiçi değil.");
                return;
            }
            StringBuilder sb = new StringBuilder("👥 **Çevrimiçi Oyuncular (" + players.size() + "):**\n");
            for (Player p : players) sb.append("• ").append(p.getName()).append("\n");
            reply(event, sb.toString().trim());
        });
    }

    private void cmdLightning(MessageReceivedEvent event, String playerName) {
        if (playerName.isEmpty()) { reply(event, "❌ Kullanım: `/lightning <oyuncu>`"); return; }
        Bukkit.getScheduler().runTask(plugin, () -> {
            Player target = Bukkit.getPlayerExact(playerName);
            if (target == null) { reply(event, "❌ **" + playerName + "** çevrimiçi değil."); return; }
            target.getWorld().strikeLightning(target.getLocation());
            reply(event, "⚡ **" + target.getName() + "**'e yıldırım düştü!");
        });
    }

    private void cmdFakeQuit(MessageReceivedEvent event, String playerName) {
        if (playerName.isEmpty()) { reply(event, "❌ Kullanım: `/fakequit <oyuncu>`"); return; }
        Bukkit.getScheduler().runTask(plugin, () -> {
            Player target = Bukkit.getPlayerExact(playerName);
            if (target == null) { reply(event, "❌ **" + playerName + "** çevrimiçi değil."); return; }
            Bukkit.broadcastMessage("§e" + target.getName() + " §7oyundan ayrıldı.");
            reply(event, "👻 **" + target.getName() + "** sahte çıkış mesajı gönderildi!");
        });
    }

    private void cmdFakeJoin(MessageReceivedEvent event, String playerName) {
        if (playerName.isEmpty()) { reply(event, "❌ Kullanım: `/fakejoin <oyuncu>`"); return; }
        Bukkit.getScheduler().runTask(plugin, () -> {
            Bukkit.broadcastMessage("§e" + playerName + " §7oyuna katıldı.");
            reply(event, "👻 **" + playerName + "** sahte giriş mesajı gönderildi!");
        });
    }

    private void cmdHelp(MessageReceivedEvent event) {
        String help = """
                📋 **AdminBridge Komutları:**
                ─────────────────────────────
                `/kick <oyuncu> [sebep]` — Oyuncuyu at
                `/ban <oyuncu> [sebep]` — Oyuncuyu yasakla
                `/unban <oyuncu>` — Yasağı kaldır
                `/broadcast <mesaj>` — Sunucuya duyuru yap
                `/list` — Çevrimiçi oyuncuları göster
                ─────────────────────────────
                🎭 **Troll Komutları:**
                `/lightning <oyuncu>` — Yıldırım düşür ⚡
                `/fakequit <oyuncu>` — Sahte çıkış mesajı
                `/fakejoin <oyuncu>` — Sahte giriş mesajı
                """;
        reply(event, help);
    }

    public void shutdown() {
        if (jda != null) {
            jda.shutdown();
        }
    }
}
