# 🎮 AdminBridge — Minecraft ↔ Discord Plugin

Paper 1.21.1 için Discord entegrasyonlu admin yönetim eklentisi.

## ✨ Özellikler

- **Action Bar** — Oyuncu sunucuya girince altın rengi hoş geldin mesajı
- **Discord Log** — Giriş/çıkış, ölüm, komut kullanımı otomatik loglanır
- **Discord Komutları** — Discord kanalından sunucuya müdahale et
  - `/kick`, `/ban`, `/unban`
  - `/broadcast` — Sunucuya duyuru
  - `/list` — Çevrimiçi oyuncular
  - `/lightning` — Yıldırım ⚡
  - `/fakequit`, `/fakejoin` — Troll mesajları 👻

---

## 🔨 JAR Derleme (GitHub Actions - Ücretsiz)

1. [github.com](https://github.com) adresinden **ücretsiz hesap** aç
2. **New Repository** → İsim ver → **Public** seç → Oluştur
3. Bu klasördeki tüm dosyaları repoya yükle (veya `git push`)
4. **Actions** sekmesine git → `AdminBridge Build` workflow'u çalış
5. Tamamlanınca **Artifacts** bölümünden `AdminBridge-Plugin.zip`'i indir
6. Zip içindeki `AdminBridge-1.0.jar`'ı al

---

## ⚙️ Kurulum

1. `AdminBridge-1.0.jar` dosyasını sunucunun `plugins/` klasörüne at
2. Sunucuyu başlat veya `/reload confirm` yap
3. `plugins/AdminBridge/config.yml` dosyasını düzenle

---

## 🔧 config.yml Ayarları

```yaml
discord:
  bot-token: "TOKEN_BURAYA"           # Discord bot token'ın
  command-channel-id: "KANAL_ID"      # Komutları yazacağın kanalın ID'si

webhooks:
  join-leave: "WEBHOOK_URL"           # Giriş/çıkış logu
  deaths: "WEBHOOK_URL"               # Ölüm logu
  commands: "WEBHOOK_URL"             # Komut logu

messages:
  join-actionbar: "✦ Hoş Geldin, {player}! ✦"
```

---

## 🤖 Discord Webhook Nasıl Alınır?

1. Discord'da log kanalına sağ tıkla → **Kanal Düzenle**
2. **Entegrasyonlar** → **Webhook'lar** → **Yeni Webhook**
3. URL'yi kopyala → `config.yml`'e yapıştır

## 🤖 Bot Token Nasıl Alınır?

1. [discord.com/developers/applications](https://discord.com/developers/applications) → **New Application**
2. **Bot** sekmesi → **Reset Token** → Kopyala
3. **Privileged Gateway Intents** → `MESSAGE CONTENT INTENT` → Aç
4. `config.yml`'e token'ı yapıştır
5. Botu sunucuna ekle: **OAuth2** → **URL Generator** → `bot` + `Send Messages` + `Read Messages`

## 📺 Kanal ID Nasıl Alınır?

Discord Ayarları → Gelişmiş → **Geliştirici Modu** aç
Komut kanalına sağ tıkla → **ID'yi Kopyala**
